- Two pipes are used in `movie-item.component.ts` to render movie budget and duration
- "The first movie on the screen displays: 
   \"Budget: $125 million Duration: 2h 32min\""
- "The sixth movie on the screen (Harry Potter and the Order of the Phoenix) displays: 
  \"Budget: $150 to $200 million Duration: 2h 18min\""
